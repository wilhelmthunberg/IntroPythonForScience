
thislist = ["more about python", "how python can be applied to solve physics problems", "how to use numpy", "how not to use numpy", "about least square approximation","some fun stuff"
]
for x in thislist:
  print('In this course i will learn {}! '.format(x))



